const Order = require("../models/Order");

// ✅ USER: place COD order
exports.createOrder = async (req, res) => {
  try {
    const { items, total } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: "Order items required" });
    }

    const order = await Order.create({
      user: req.user._id,
      items,
      total,
      payment: "COD",
      status: "Pending",
    });

    res.status(201).json(order);
  } catch (err) {
    console.error("CREATE ORDER ERROR:", err);
    res.status(500).json({ message: "Server error" });
  }
};

// ✅ USER: order history
exports.getMyOrders = async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id })
      .sort({ createdAt: -1 });

    res.json(orders);
  } catch (err) {
    console.error("MY ORDERS ERROR:", err);
    res.status(500).json({ message: "Server error" });
  }
};

// ✅ OWNER: view all orders (simple version)
// Later we can filter by owner restaurant/products
exports.getOwnerOrders = async (req, res) => {
  try {
    const orders = await Order.find()
      .populate("user", "name email")
      .sort({ createdAt: -1 });

    res.json(orders);
  } catch (err) {
    console.error("OWNER ORDERS ERROR:", err);
    res.status(500).json({ message: "Server error" });
  }
};

// ✅ OWNER: update status
exports.updateOrderStatusOwner = async (req, res) => {
  try {
    const { status } = req.body;
    const allowed = ["Pending", "Accepted", "Rejected", "Delivered"];

    if (!allowed.includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: "Order not found" });

    order.status = status;
    await order.save();

    res.json({ message: "Status updated", order });
  } catch (err) {
    console.error("OWNER STATUS ERROR:", err);
    res.status(500).json({ message: "Server error" });
  }
};
