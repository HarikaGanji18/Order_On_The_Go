const express = require("express");
const cors = require("cors");
require("dotenv").config();

const connectDB = require("./config/db");

const app = express();

// middleware
app.use(cors({ origin: true })); // simple CORS
app.use(express.json());

// connect db
connectDB();

// routes
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/admin", require("./routes/adminRoutes")); // ✅ IMPORTANT
app.use("/api/orders", require("./routes/orderRoutes")); // optional if you have
app.use("/api/products", require("./routes/productRoutes")); // optional if you have
app.use("/api/restaurants", require("./routes/restaurantRoutes")); // optional if you have
app.use("/api/cart", require("./routes/cartRoutes")); // optional if you have

app.get("/", (req, res) => res.send("SB Foods API Running..."));

const PORT = process.env.PORT || 6001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
