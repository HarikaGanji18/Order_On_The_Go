const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },

    items: [
      {
        id: String,
        name: String,
        price: Number,
        qty: Number,
        img: String,
        category: String,
      },
    ],

    total: { type: Number, required: true },

    payment: { type: String, default: "COD" }, // COD
    status: { type: String, default: "Pending" }, // Pending/Accepted/Rejected/Delivered
  },
  { timestamps: true }
);

module.exports = mongoose.model("Order", orderSchema);
