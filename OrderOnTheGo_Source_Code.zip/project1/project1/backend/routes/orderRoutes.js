const express = require("express");
const router = express.Router();

const protect = require("../middleware/authMiddleware");
const roleOnly = require("../middleware/roleMiddleware");

const {
  createOrder,
  getMyOrders,
  getOwnerOrders,
  updateOrderStatusOwner,
} = require("../controllers/orderController");

// User places order
router.post("/", protect, roleOnly(["user"]), createOrder);

// User order history
router.get("/my", protect, roleOnly(["user"]), getMyOrders);

// ✅ Owner view incoming orders
router.get("/owner", protect, roleOnly(["owner"]), getOwnerOrders);

// ✅ Owner update status (Pending → Accepted/Rejected/Delivered)
router.put("/:id/status", protect, roleOnly(["owner"]), updateOrderStatusOwner);

module.exports = router;
