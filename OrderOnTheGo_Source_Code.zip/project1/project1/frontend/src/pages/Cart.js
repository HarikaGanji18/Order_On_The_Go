import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api/axios";
import "./cart.css";

const CART_KEY = "sbfood_cart";

function readCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
  } catch {
    return [];
  }
}

function writeCart(items) {
  localStorage.setItem(CART_KEY, JSON.stringify(items));
}

export default function Cart() {
  const navigate = useNavigate();
  const [items, setItems] = useState(readCart());
  const [loading, setLoading] = useState(false);

  const total = useMemo(() => {
    return items.reduce((sum, it) => sum + it.price * it.qty, 0);
  }, [items]);

  const changeQty = (id, delta) => {
    const updated = items
      .map((it) => (it.id === id ? { ...it, qty: it.qty + delta } : it))
      .filter((it) => it.qty > 0);

    setItems(updated);
    writeCart(updated);
  };

  const clearCart = () => {
    setItems([]);
    writeCart([]);
  };

  const placeOrderCOD = async () => {
    // ✅ Only USER can place order (prevents 403)
    const role = localStorage.getItem("role");
    if (role !== "user") {
      alert("Only User account can place orders. Please login as User.");
      navigate("/login");
      return;
    }

    if (items.length === 0) return alert("Cart is empty!");

    try {
      setLoading(true);

      await api.post("/api/orders", {
        items,
        total,
        payment: "COD",
      });

      alert("✅ Order placed successfully (Cash on Delivery)");
      clearCart();
      navigate("/orders");
    } catch (err) {
      console.error(err);
      alert(err?.response?.data?.message || "Order failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="cart-page">
      <header className="cart-header">
        <div>
          <h2>Your Cart</h2>
          <p className="sub">Payment method: Cash on Delivery</p>
        </div>

        <div className="actions">
          <Link className="linkbtn" to="/menu">
            ← Back to Menu
          </Link>
          {items.length > 0 && (
            <button className="outline" onClick={clearCart}>
              Clear Cart
            </button>
          )}
        </div>
      </header>

      {items.length === 0 ? (
        <div className="empty">
          <h3>🛒 Cart is empty</h3>
          <p>Add food items from the menu.</p>
          <Link className="primaryLink" to="/menu">
            Go to Menu
          </Link>
        </div>
      ) : (
        <>
          <div className="list">
            {items.map((it) => (
              <div className="item" key={it.id}>
                <img
                  className="img"
                  src={it.img}
                  alt={it.name}
                  onError={(e) => {
                    e.target.src =
                      "https://images.unsplash.com/photo-1604908176997-125f25cc500f?auto=format&fit=crop&w=600&q=80";
                  }}
                />

                <div className="info">
                  <h4 className="name">{it.name}</h4>
                  <p className="meta">{it.category}</p>
                  <p className="price">₹{it.price} each</p>
                </div>

                <div className="qty">
                  <button onClick={() => changeQty(it.id, -1)}>-</button>
                  <span>{it.qty}</span>
                  <button onClick={() => changeQty(it.id, 1)}>+</button>
                </div>

                <div className="lineTotal">₹{it.price * it.qty}</div>
              </div>
            ))}
          </div>

          <div className="summary">
            <div className="sumRow">
              <span>Total</span>
              <b>₹{total}</b>
            </div>

            <p className="note">
              Cash on Delivery — pay when food is delivered.
            </p>

            <button
              className="primary"
              onClick={placeOrderCOD}
              disabled={loading}
            >
              {loading ? "Placing Order..." : "Place Order (COD)"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
